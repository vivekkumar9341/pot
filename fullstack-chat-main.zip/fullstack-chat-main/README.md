# Fullstack Chat project

This project allows to setup fullstack chat for any frontend/backend combination!

Connect React, Vue, or Angular and any backend you wish!

This should fully support all your fullstack chat needs!

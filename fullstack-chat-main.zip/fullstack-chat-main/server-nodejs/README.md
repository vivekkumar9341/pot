## NodeJS Server Setup

```
npm init
npm install express axios cors
npm install --save-dev nodemon
# Add: "scripts": { "start": "nodemon index.js" },
echo node_modules/ > .gitignore
touch index.js
# Add the code
npm run start
```

Edit the package.json file
